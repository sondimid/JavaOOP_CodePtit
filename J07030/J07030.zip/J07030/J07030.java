package J07030;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.TreeSet;

public class J07030 {
    public static boolean isPrime(int n){
        for(int i = 2; i <= Math.sqrt(n); i++){
            if(n % i ==0 ) return false;
        }
        return n > 1;
    }
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectInputStream file1 = new ObjectInputStream(new FileInputStream("DATA1.in"));
        ObjectInputStream file2 = new ObjectInputStream(new FileInputStream("DATA2.in"));
        TreeSet<Integer> list1 = (TreeSet<Integer>) file1.readObject();
        TreeSet<Integer> list2 = (TreeSet<Integer>) file2.readObject();

        for(Integer value : list1){
            if(isPrime(value) && list2.contains(1000000-value) && isPrime(1000000 - value)){
                System.out.println(value.toString() + (1000000-value));
            }
        }
    }
}
