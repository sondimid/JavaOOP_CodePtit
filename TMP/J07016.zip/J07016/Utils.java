package J07016;

public class Utils {
    public static boolean isPrime(Integer value){
        for(int i = 2; i <= Math.sqrt(value); i++){
            if(value % i == 0) return false;
        }
        return value > 1;
    }
}
