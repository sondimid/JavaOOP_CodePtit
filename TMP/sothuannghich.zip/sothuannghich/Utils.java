package sothuannghich;

import java.util.List;


public class Utils {
    public static boolean oke(Integer n) {
        String s = Integer.toString(n);
        if (s.length() == 1 || s.length() % 2 == 0)
            return false;
        for (int i = 0; i <= s.length() / 2; ++i) {
            if (s.charAt(i) % 2 == 0)
                return false;
            if (s.charAt(i) != s.charAt(s.length() - i - 1))
                return false;
        }
        return true;
    }

    public static void print(List<Pair> list) {
        for (Pair pair : list) {
            System.out.println(pair);
        }
    }
}
