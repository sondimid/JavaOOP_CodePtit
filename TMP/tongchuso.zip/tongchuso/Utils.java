package tongchuso;

public class Utils {
    public static boolean isNumber(Character s){
        try{
            Integer.parseInt(s.toString());
        }
        catch(Exception e){
            return false;
        }
        return true;
    }

}
