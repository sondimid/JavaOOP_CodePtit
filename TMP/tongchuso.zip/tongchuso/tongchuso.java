package tongchuso;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class tongchuso {
    public static void main(String[] args) {
        // Sử dụng try-with-resources để tự động quản lý tài nguyên
        try (ObjectInputStream file1 = new ObjectInputStream(new FileInputStream("DATA.in"))) {
            ArrayList<String> list = (ArrayList<String>) file1.readObject();

            // Duyệt qua từng chuỗi trong danh sách
            for (String str : list) {
                StringBuilder sb = new StringBuilder();
                int sumOfDigits = 0;

                // Tách các chữ số và tính tổng
                for (int i = 0; i < str.length(); i++) {
                    char ch = str.charAt(i);
                    if (Character.isDigit(ch)) {
                        sb.append(ch);
                        sumOfDigits += ch - '0';  // Cộng giá trị số của chữ số
                    }
                }

                String val = sb.toString();
                if (!val.isEmpty()) {
                    // Bỏ đi các chữ số 0 ở đầu
                    long numericValue = Long.parseLong(val);
                    System.out.println(numericValue + " " + sumOfDigits);
                } else {
                    // Nếu không có chữ số nào
                    System.out.println("0 0");
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}