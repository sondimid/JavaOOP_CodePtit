package cau15;

public class Time {
    private String idTeacher, idMonHoc;
    private double time = 0;

    public Time(String idTeacher, String idMonHoc) {
        this.idTeacher = idTeacher;
        this.idMonHoc = idMonHoc;
    }
}
